/*
Programmer: Cole Rodenberg
Description: This program recieves the sender's and receiver's names and then produces a business letter to reschedule a meeting for a week in advance.
Date: 9/24/2016
 */
package crbusinessletter;
//import java.awt objects
import java.awt.BorderLayout;import java.awt.Color;import java.awt.Dimension;import java.awt.Font;import java.awt.GridBagConstraints;import java.awt.GridBagLayout;
import java.awt.Insets;import java.awt.Toolkit;import java.awt.event.ActionEvent;import java.awt.event.ActionListener;

//import javax.swing objects
import javax.swing.DefaultListModel;import javax.swing.JButton;import javax.swing.JFrame;import javax.swing.JLabel;import javax.swing.JList;import javax.swing.JOptionPane;
import javax.swing.JPanel;import javax.swing.JTextField;import javax.swing.JComboBox;
//import others
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

public class CRBusinessLetter extends JFrame{
    
    //Global variables
    JButton submit;
    JTextField firstName, lastName, toLast, toFirst;
    JLabel title, nLabel1, nLabel2, nLabel3, nLabel4;
    String[] infoList = new String[5];
    JList defNameList;
    JComboBox titleList;
    DefaultListModel defListModel = new DefaultListModel();
    
    public static void main(String[] args) {
        CRBusinessLetter letter = new CRBusinessLetter();
    }//End main
    
     //Default constructor
    public CRBusinessLetter(){
        
        //Set the size of the window
        this.setSize(900,800);
        Toolkit tk = Toolkit.getDefaultToolkit();

        //Set postion of the window
        Dimension dim = tk.getScreenSize();
        int xPos = (dim.width / 2) - (this.getWidth()/2);
        int yPos = (dim.height / 2) - (this.getHeight()/2);
        this.setLocation(xPos, yPos);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Business Letter Creator");

        //Declare and Setup windowPanel, titlePanel, and mainPanel
        JPanel windowPanel = new JPanel();
        windowPanel.setLayout(new BorderLayout());
        JPanel titlePanel = new JPanel();
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());

        //Set the gridConstraints
        GridBagConstraints gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.gridwidth = 1;
        gridConstraints.gridheight = 1;
        gridConstraints.weightx = 50;
        gridConstraints.weighty = 50;
        gridConstraints.insets = new Insets(1,1,1,1);
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.fill = GridBagConstraints.NONE;

        //Declare and set up combo box
        String[] titleStrings = {"Mr.", "Mrs.", "Ms.", "Dr."};
        titleList = new JComboBox(titleStrings);
        titleList.setSelectedIndex(0);
        titleList.setFont(new Font("Courier New",Font.PLAIN, 30));
        
        //Declare Labels and set fonts
        title = new JLabel("Please Enter Business Letter Information");
        title.setFont(new Font("Courier New",Font.PLAIN, 30));
        nLabel1 = new JLabel("Your first name:");
        nLabel1.setFont(new Font("Courier New",Font.PLAIN, 30));
        nLabel2 = new JLabel("Your last name:");
        nLabel2.setFont(new Font("Courier New",Font.PLAIN, 30));
        nLabel3 = new JLabel("First name of client:");
        nLabel3.setFont(new Font("Courier New",Font.PLAIN, 30));
        nLabel4 = new JLabel("Last name of client:");
        nLabel4.setFont(new Font("Courier New",Font.PLAIN, 30));
        
        //Declare Text Fields and set fonts
        firstName = new JTextField("", 15);
        firstName.setFont(new Font("Courier New",Font.PLAIN, 30));
        lastName = new JTextField("", 15);
        lastName.setFont(new Font("Courier New",Font.PLAIN, 30));
        toFirst = new JTextField("", 15);
        toFirst.setFont(new Font("Courier New",Font.PLAIN, 30));
        toLast = new JTextField("", 15);
        toLast.setFont(new Font("Courier New",Font.PLAIN, 30));
        
        //Declare Button
        submit = new JButton("Submit");
        submit.setFont(new Font("Courier New",Font.PLAIN, 30));
        ListenForButton lForButton = new ListenForButton();
        submit.addActionListener(lForButton);

        //Add labels, title, and textfields to main
        titlePanel.add(title);
        mainPanel.add(titlePanel);
        mainPanel.add(nLabel1, gridConstraints);
        
        //Build the Panel
        gridConstraints.gridwidth = 20;
        gridConstraints.gridx = 5;
        mainPanel.add(firstName, gridConstraints);
        gridConstraints.gridwidth = 1;
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        mainPanel.add(nLabel2,gridConstraints);
        gridConstraints.gridx = 5;
        mainPanel.add(lastName,gridConstraints);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        mainPanel.add(nLabel3,gridConstraints);
        gridConstraints.gridx = 3;
        mainPanel.add(titleList,gridConstraints);
        gridConstraints.gridx = 5;
        mainPanel.add(toFirst,gridConstraints);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        mainPanel.add(nLabel4,gridConstraints);
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 4;
        mainPanel.add(toLast,gridConstraints);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 5;
        gridConstraints.anchor = GridBagConstraints.EAST;
        mainPanel.add(submit, gridConstraints);

        //Add main and title panels to main
        windowPanel.add(titlePanel, BorderLayout.PAGE_START);
        windowPanel.add(mainPanel, BorderLayout.CENTER);

        this.add(windowPanel);

        this.setVisible(true);
    }//End constructor
    
    //ListenForButton is the event that takes action whenever the submit button is clicked. This action checks that the user correctly
    //entered the inputs and then it stores the inputs into the infoList array. Then the action calculates the total money earned and 
    //calls the drawCheck function with the correct information as parameters.
    public class ListenForButton implements ActionListener{
        public void actionPerformed(ActionEvent e){
            JPanel checkDisplay = new JPanel();
            String tempFirst = firstName.getText();
            String tempLast = lastName.getText();
            String fUpper, lUpper, fLower, lLower;
            
            if(e.getSource() == submit){
                
                //Check firstName input and capitalize name
                if(firstName.getText().isEmpty() != true && (firstName.getText().matches("[a-zA-Z]*"))){
                    fUpper = tempFirst.substring(0, 1);
                    fLower = tempFirst.substring(1, tempFirst.length());
                    fUpper = fUpper.toUpperCase();
                    fLower = fLower.toLowerCase();
                    tempFirst = fUpper + fLower;
                    infoList[0] = tempFirst;
                }//End if
                else{
                        JOptionPane.showMessageDialog(null, "Please enter in a first name without special characters or numbers", "Input Error", JOptionPane.WARNING_MESSAGE);
                        return;
                }//End else
                
                //Check lastName input and capitalize name
                if(lastName.getText().isEmpty() != true && (lastName.getText().matches("[a-zA-Z]*"))){
                    lUpper = tempLast.substring(0, 1);
                    lLower = tempLast.substring(1, tempLast.length());
                    lUpper = lUpper.toUpperCase();
                    lLower = lLower.toLowerCase();
                    tempLast = lUpper + lLower;
                    infoList[1] = tempLast;
                }//End if
                else{
                        JOptionPane.showMessageDialog(null, "Please enter in a last name without special characters or numbers", "Input Error", JOptionPane.WARNING_MESSAGE);
                        return;
                }//End else
                
                //Check toFirst input and capitalize name
                if(toFirst.getText().isEmpty() != true && (toFirst.getText().matches("[a-zA-Z]*"))){
                    fUpper = tempFirst.substring(0, 1);
                    fLower = tempFirst.substring(1, tempFirst.length());
                    fUpper = fUpper.toUpperCase();
                    fLower = fLower.toLowerCase();
                    tempFirst = fUpper + fLower;
                    infoList[3] = tempFirst;
                }//End if
                else{
                        JOptionPane.showMessageDialog(null, "Please enter in a client first name without special characters or numbers", "Input Error", JOptionPane.WARNING_MESSAGE);
                        return;
                }//End else
                
                //Check toLast input and capitalize name
                if(toLast.getText().isEmpty() != true && (toLast.getText().matches("[a-zA-Z]*"))){
                    lUpper = toLast.getText().substring(0, 1);
                    lLower = toLast.getText().substring(1, toLast.getText().length());
                    lUpper = lUpper.toUpperCase();
                    lLower = lLower.toLowerCase();
                    tempLast = lUpper + lLower;
                    infoList[4] = tempLast;
                }//End if
                else{
                        JOptionPane.showMessageDialog(null, "Please enter in a client last name without special characters or numbers", "Input Error", JOptionPane.WARNING_MESSAGE);
                        return;
                }//End else
               
                //get title value and create the current date and date a week in the future
                infoList[2] = titleList.getSelectedItem().toString();
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                Calendar rightNow = Calendar.getInstance();
                Calendar weekFromToday = Calendar.getInstance();
                weekFromToday.add(Calendar.DATE, 7);
                
                //Display letter
                JOptionPane.showMessageDialog(null, "Acknowledgment of Change in Meeting Date\n" +"Dear " + infoList[2] + " " + infoList[4] + ",\n" +"Following your request, we have changed your meeting "
                        + "time with " + infoList[0] + " " + infoList[1] + " from " + dateFormat.format(rightNow.getTime()) + ",\n to " + dateFormat.format(weekFromToday.getTime()) + " on one of the dates you mentioned that would suit you. We are pleased\n that we are "
                        + "able to accommodate you in this matter, and " + infoList[0] + " " + infoList[1] + " is looking forward to your \nmeeting on this newly appointed date. By any chance, it is still "
                        + "not acceptable or you need to make a\nchange in the hour, don't hesitate to contact us and we will assist you to the best of our ability. \nYours sincerely,\n"+"\n"
                        + infoList[0] + " " + infoList[1], "Formal Letter", JOptionPane.INFORMATION_MESSAGE);
                
            }//End if
        }//End actionPerformed
    }//End ListenForButton
}//End class
